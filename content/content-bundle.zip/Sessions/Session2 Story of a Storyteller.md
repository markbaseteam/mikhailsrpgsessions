## 2 - Story of a Storyteller

Summer, days 6-8

 - starts out immediately after killing the privateer guy and making sure he was dead

- searched the temple, a group of armed men approached

- attempted to reason with them, but they saw the bloody mess at the top of the temple and attacked

- defeated them, took their horses, rested a bit

- stayed at the temple for the night, but in the morning inspecting the top of the dais the body was gone, blood smears into the hole at the top and a horrible screeching

- traveled down the road at the goober’s pointing, came across an old man on a hill crying, surrounded by goobers

- Gawain tried to console the man, but he was too sad and didn’t understand our language (nor us his)

- the goober sent us further down the road to a mining village

- the people around the campfire in the center of town attacked (even though Gawain and Camren tried to approach non-threateningly)

- Camren knocked unconscious and bleeding; Skylar shoved a revitalizing steak into her mouth and forced her to chew and swallow. (haha) Gawain kept getting knocked out, Skylar and Trebor running back and forth trying to keep G on his feet and fighting.

- killed the hostiles, started poking around the houses. Trebor discovered a girl tied up inside one of the houses. He came outside to report, Camren rolled her eyes, went in, and untied the girl.

- Reunited the girl with the man. He was grateful, let the party stay in his tiny hut overnight, let Trebor and Camren look through the books in his library. The man and his daughter tried to teach T + C some of the language. The man explained one of Trebor’s scrolls, showing him it was a spell. Trebor found out how to make his spell stronger. Skylar and Gawain experimented with some items, discovered how the black lantern worked.

- The storyteller gave Camren a book. The first entry told the story of the four and how they’d rescued his daughter.

- Storyteller packed up and left. Shortly after, horses coming down the road. The goober freaked out and pointed for everyone to leave. Rushed out the back door and into the woods without any time to retrieve the horses.

- Ran on foot. Being closed in on all sides by riders. Three of them reached the group; the group fought against them. Camren took a nasty hit that should’ve knocked her out but, miraculously, did not. She was very confused. Trebor tried to take one of the riders helmets and had to be dragged away by Skylar because hoofbeats were still headed towards them. 