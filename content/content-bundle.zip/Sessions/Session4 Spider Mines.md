
## 4 - Spider Mines
Summer, day 13
Skylar and Trebor stared helplessly at the bitter argument happening in the middle of the mining village.
“This is it? This is all you got? They ripped us off!” Gawain said, throwing his hands up at the satchel Camren brought back. Inside was enough bread, cheese, and a bit of dried meat to last each of them one day.  “A whole gold piece?! Renting a boat at the port cost six silver!”

Camren was fed up with Gawain’s red-faced sputtering. It had been difficult enough to try and communicate they wanted to buy food, let alone with villagers so terrified they’d run and hid as soon as the group came down the path. “Fine,” Camren said. “I’m leaving. If you want to barter, go ahead.”

Gawain stormed up to the villager’s house and knocked on the door while Camren and Skylar turned their backs, went to the end of the road leading out of the village, and waited for the damage to be done.

“Hello?” Gawain said. “I want to talk.”

The back door slammed and the family ran for the woods. Gawain had the front door halfway open, but when he saw the children running and the fear in the parents’ faces, the thought he had to simply walk in and take the food they’d paid for dissipated. He closed the door and looked around for the rest of the party.

Torn between Gawain and Camren, Trebor noticed a smithy toward the village’s edge. The blacksmith opened the door and regarded Trebor with caution.

Using a stick, Trebor drew out a picture of the door spikes they needed to repair the keep’s doors. The smith invited Trebor inside, and after a lot of hand gesturing and pointing Trebor paid one gold for two ingots’ worth of spikes. They would be ready after a few days of labor. (He thought, anyway; it was impossible to know for sure.)
The smith pointed to a bag of raw ore and then to a path leading out the back of the village. If they wanted more door spikes they’d need to bring more materials. Trebor gathered Camren, Skylar, and Gawain. “I think if we want more ore, the mine is this way,” Trebor said.

What Trebor should have said is that if they wanted more spiders, the web was this way. After over an hour of walking that’s what they got.

A layer of white draped over squat stone houses at the base of a sheer cliff. There was no way to see through the thick silk, nor was there any way to get in. Along the top of the web tent they could see movement. Whatever it was, it wasn’t human. It was probably spiders.

Yep. It was spiders.

Camren gets wrapped up by the little spider. Yelling for help. Gawain slew it. Skylar cuts Camren free.
Cut open the sac. Child dropped from it. Everyone failed miserably at trying to calm the kid. The kid runs off.
Slicing into the web was tedious and difficult. They backed up and went around the edge towards the movement. Camren cut in and discovered a door. Went inside. Blanket of living spiders. A man, withered, tar like blobs oozing from his face. Bones covered the makeshift altar before him. A voice hissed inside everyone’s minds. “Have you come to worship, or have you come to join the mayor and his lackeys?”

Camren looked at the spiders, looked at the ugly visage of a man before her, and gave her response in the form of a flaming short sword. Flammable objects be damned. Seconds later an arrow thocked the priest in the shoulder: Gawain was able to hit him through the open window. Not that it mattered, because Trebor came tearing into the house and slashed the priest wide open with a sword engulfed in fire. The priest crumpled to the ground and all the little spiders scuttled up, away, cramming into cracks and corners.

Skylar breathed a sigh of relief seeing the big spider advancing around the corner of the house take off. She started to hack her way through the webs, cutting towards the column of smoke rising from the chimney nearby. On the other side she saw a man swinging a blade and clearing a path. He shouted and waved.

With all four of the crew they cut a path to what turned out to be another smithy. The owner helped free the rest of the villagers from the web balls.

Gawain tried to buy some ore. The blacksmith pointed toward a path leading up the cliffside. He wouldn’t accept the money. Beginning to realize there were a lot of people missing from this village. It seemed there was more pest control to be done.

They entered the mine by the light of Trebor, Skylar, and Camren’s fire weapons and shields. Fortunately they found an oil lamp in a minecart near the entrance. Skylar lit it up and held the lantern aloft, illuminating the rest of the area.
Room one - spiders, egg sacs, humans netted to the walls and eaten

Room two - spiders, living humans netted to walls, beginning to feel the burn (Trebor and Camren seriously hurt, one of the villagers points to the potions and indicates blue is good green is bad)

Room three - ghosts

Room four - giant spider shaft. Camren lit a scrap of cloth on fire and let it drop down. She waited. The bit of fire landed on the floor below and burned for a bit before it went out.

A scraping scratching sound started climbing up the walls. Camren leapt back and prepared to run. Whatever this thing was, it was big, and she wasn’t up to taking that many more hits.

Gawain hurried to the edge, nocked an arrow, and shot at the form slipping along the walls. Hairy spider legs shot over the edge of the scaffolding and lashed at Gawain. These legs, and the disgusting multi-eyed body that rose over the edge, were bigger than any spider had a right to be.

Everyone panicked. Well, everyone except Gawain. He kept shooting at the beady red eyes in front of him.
Skylar rushed backward before realizing if she ran, there was no way anyone was going to survive. With shaking hands she started cranking the hurdy gurdy and plucking the strings. It was enough to give Camren the courage to rush the spider too, since Gawain wasn’t fleeing. Trebor secured his bandages and prepared to run.

“The [[ghosts]] We have to get this thing to the [[ghosts]]!” Camren shouted.

Camren dashed away from the spider’s spindly legs. Gawain wasn’t so lucky. He got a few steps away before something gooey smacked the back of his neck and pulled him to the ground. Before he knew it he was being dragged under and behind the monster. With great difficulty he knocked an arrow and struck the spider’s underside. It screeched.

The three of them ran but the spider was faster. The music faltered and stopped. They were just blindly running now. Skylar couldn’t keep up. Legs stomped and scratched at her, and then she was being weaved round and round. She struggled, keeping her arms free, but that was all she could do.

Trebor and Camren tore into the ghost room. The spider spat on Trebor and dragged him into its deathly grip. At the same time it kicked Gawain and sliced his chest open, knocking him in the head. He went limp. Skylar was still struggling.

Camren was the only one standing. This was it. She looked at the ghosts teaming along the back wall, their twisted angry faces directed towards her.

White wraiths whooshed past, mobbed the spider, and it collapsed. One long hairy leg twitched and then fell still. The wraiths vanished into thin air.

Gawain wasn’t responding. It took all three of them multiple tries to stabilize the bleeding. He was conscious, but he couldn’t move, couldn’t talk. He wasn’t leaving any way except on a stretcher. Camren made him drink the last blue potion and watched the bizarre magical effects kick in. Gawain was able to stand and hobble over to the miner’s shrine near the entrance.

Trebor and Skylar bashed in the locked door in the main compound. Inside appeared to be an office, with some notes on a desk and a safe in the corner. It didn’t seem right to break into the safe and disturb this room any further. Trebor sat with Gawain and focused on bandaging his wounds.

Skylar and Camren went to investigate the downward spiralling shaft. With each level of stairs they grew more nervous, but in the end they made it to the bottom. Skylar took one look at the bodies piled before the glassy, part-human part-spider statue and turned and ran up the stairs.

Camren needed to see this through. She wanted to bring something back to the village to communicate the fate of the mayor. She took a step into the room.

A metallic screeching voice brought Camren to her knees and ripped through her mind, as well as the minds of all her comrades. “You have killed my priest, massacred my children, and destroyed my avatar, and so shall I destroy you. More shall come!”

The statue tipped and shattered. Camren didn’t want to stay here any longer. She removed the medallion from the mayor and turned to leave, but as she did so she noticed some of the shards were different from the others. She picked up the unusual one at her feet. It was an emerald. More glittered around the room.

Medallion and single emerald in hand, Camren returned to the others. Trebor and Skylar hurried to gather the rest of the gems from the bottom of the shaft.

Trebor gets entranced by a glowy thingy on the wall

return to the village, Camren tries to negotiate ore, village feast, Camren takes medallion and offers it to other companions

any ideas on how to protect a village and a keep?
