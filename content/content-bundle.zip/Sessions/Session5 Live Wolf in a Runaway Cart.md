## 5 - Live Wolf in a Runaway Cart

It was clear that surviving a near death in the Spider Mines took a toll on some of us, so if we walked away with a fear of spiders, or a tendency to check the shadows in the room more than once, or a strange attachment to spiderwebs, well, that was to be expected.  

Some of our friends at the mining village pointed out that we had missed some useful items the crazed spider cultist used often. After rest, food, purchasing some rations, and fending off a couple of starving wolves on the road, we went back to sift through the spider area. The time spent rewarded us with a poison dagger and a wooden wand. Skylar collected blankets from the bed to make new bandages. Camren learned the robes from the cultist made it easy to travel through spiderwebs.

Unfortunately when we got back to the mining village only Gawain and Skylar were fast enough to get out of sight of the horsemen riding through town. Camren and Trebor took a stand outside while two of the riders broke into the house Gawain and Skylar hid in. The riders did not carry anything useful. And, as usual, a survivor rode off.

We grabbed the horses and argued about which route to take. When we attempted to flee in one direction, the villagers stopped us. That way was bad, without a doubt, so we fled for the keep.

Trebor wanted to go FAST. He succeeded… for a while. By the time Camren caught up with him and Gawain, Trebor was dragging by his clothes on the ground. Despite any attempts to calm the horses the beasts were having as bad a day as we were. We freed them and ran into the grass to hide. Our pursuers thundered down the road. We did not see them again.

Continuing on to the keep we met up with the supply cart with the materials for our doors. At first it seemed like a good idea to ride in the cart and rest our feet. Nighttime began to set in.

That was when the wolves howled.  

Our cart driver urged the horse faster. The road became bumpy, and the wolves attacked. They were determined to bring down the horse - and the cart with it. These were not the starving creatures from the other side of the mining village.  

Gawain shot for the wolves harrying the horse. With only one ranged weapon there was little for the rest of us to do besides swing swords and play music. One of the wolves jumped into the cart. By the time we dispatched it the cart’s left wheel began to rumble chaotically.  

Camren leapt from the cart, slashing a wolf that had gotten run under the wheels earlier. The creature died and Camren ran like hell to keep up with the runaway cart. We couldn’t clear the wolves fast enough.  

The cart wheel flew. Supplies did too.  

Trebor and Gawain hit hard and fell unconscious. Skylar managed to stand. Camren fought off the last wolf, setting the thing on fire before rushing to help her companions up. Strangely though a simple swipe from the wolf felled her, too.  

If not for Skylar we’d all be dead. She snapped us out of shock so we could treat our wounds before we bled dry. Something was wrong. Yes… fighting a live wolf in a runaway cart was an insane task… but we shouldn’t have fallen so easily. 

Beaten and bloodied yet again, we took another mental hit. Trebor spent a while searching for the door hinges that’d flown from the supplies. He seemed obsessed.  

We camped in the woods. Camren poured over the storyteller’s book. It was Trebor who realized that the reason its magic stopped wasn’t because the stories weren’t being recorded, but because they needed to be told. We’ve been reading them to each other since. Who would understand our language anyway?  

We had to stash the lumber under the canvas by the road because we can’t carry it ourselves without spending a lot of time, or finding help, or another cart. The other materials we carried home.  

At the doorway a man sat eating an apple. We’re not sure why he was there - maybe to be amused. He only stuck around long enough to see us get rushed by the cave bear that’d settled in the keep while we were away. We really need to fix those doors.  

The bear escaped. We should attempt tracking it in an hour or so for the fur, fat, and meat.