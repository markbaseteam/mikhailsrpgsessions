## 3 - The Keep

Summer, days 8 (war), 9-12 (keep)

The four adventurers crashed through the woods on their newly “acquired” horses. A break in the woods up ahead might be their only chance to avoid the net closing in around them. But if they thought they’d be able to hide in the village across the river, they were sorely mistaken.

Clashes of steel on steel rang out as humans and goobers fought against each other. Riderless warhorses thrashed lethal hooves at goobers who came too close. Between two buildings the elder goober woman from before rallied her people against the press of human metal.

Camren charged across the river without hesitation, slamming her steed into the nearest soldier attacking the elder’s group. In spite of the nasty surprise, the soldier managed to grab the horse’s leg and avoid being trampled. While he fought against Camren, the rolling sound of Skylar’s hurdy gurdy rolled over the battle, emboldening the party and their allies.

Gawain loosed arrows into the fray and Trebor spoke the words that set his sword alight. Two more horsemen emerged from the forest and attacked Gawain.  

The skirmish ended quickly when one of the goobers defending the elder lashed out in fury at the human commander. The commander’s great helm disappeared from view and took the human’s resolve with it. Warhorses fled left and right.  

The elder goober was on the ground, held up by one of her people. A gash from shoulder to hip stretched wide across her torso. Fresh blood continued to leak from the fatal wound.

Camren scrambled off her horse and tore the last vial of goober goo from her belt. She slathered it over the wound without much idea whether it would make a difference or not. The goo stopped the bleeding and closed the wound. Goobers stuck their leader to a hastily constructed rack of sticks and carried her away.  

“Is this a great helm? Help me get this great helm off,” Trebor said, still obsessed with head safety. The others were starting to wonder if this was his way of coping with stress. He pried the coif and huge helmet off the dead commander and tried it on. Maybe this would make him feel better.  

Everyone else was much more concerned about whether or not one of their few allies in this insane place was still alive. The four adventurers followed the goobers into the woods. 

The elder lie on the stick bed, her breathing uneven, harsh. She reached a shaky hand for Trebor. He scuffled with the great helmet to take it off quickly. There wasn’t much time. “Aaaaah,” the elder rasped. Nobody could understand her.  

Trebor tried to communicate with his hands. What did she need? What was she saying? He leaned in, tense, expecting the blow. It didn’t happen.  

“Aaaagh,” cracked the elder’s voice. She beckoned Trebor closer with her arm. He brought his face up to hers.  

Not sure what else to do, he asked again. “Are-”  

She spit in his mouth. A great, big, disgusting ball of goo hocked from her lips and into Trebor’s throat. She cackled once and fell asleep.  

He couldn’t breathe.  

Gawain immediately leapt to the rescue, cramming a finger down Trebor’s throat to try and unstick the glue blocking his windpipe. Gawain must have forgotten how goober goo worked, because now not only was Trebor turning purple and struggling for air, but he got to do it with Gawain’s finger lodged in his mouth.   

The one tiny goober attending the shaman was laughing hysterically. He fell to the ground and rolled while Gawain pulled furiously at his stuck finger, shaking Trebor’s head back and forth in the process. Now Skylar was laughing too. Trebor fell unconscious.   

In a panic, Camren dug around in her pack for anything that would unstick the goober goo before Trebor suffocated. “What do I do?” she shouted.  

There was only one way to unstick goober goo.  

Gawain yelled, “Grab that goober, whip his dick out, and squeeze!”  

So that’s exactly what Camren did.  

Skylar was laughing so hard she was crying. Her three friends were balled up together, Camren squeezing the little goober in one hand like a lemon over Trebor’s open mouth, Gawain tugging at full force to free his finger. The goo unstuck and Gawain flew backward. Trebor coughed and coughed, unsure of what the awful rancid flavor burning his tongue was. He curled into a ball on his side and decided it was appropriate to throw up a little. Skylar was still laughing.  

Trebor had a vision of a floor plan. Along with the image, he sensed up ahead there was a battle critically important to the goobers. He scrawled down what he could remember before it faded.  

Goobers flowed freely through the clearing now, all headed in one direction. It was clear they had to act now or it would be too late for whatever was about to happen. Trebor was in bad condition after the last skirmish but there was no time to rest, so he gulped down the last of the healing drinks they had. Each of them knew if they fell, there would be no getting back up. They followed a gaggle of goobers to the field.

It was war.  

Yes, they’d come from a war-torn continent, but none of them had been in one before. Yes, they’d survived a shipwreck and whatever dirty intentions the leader planned for them on arrival. Sure, they’d fought a few battles here and there. This was different.  

It was so loud they couldn’t hear each other. Broken bodies were already strewn through the ruins, more falling each moment they spurred their horses forward. Packs of wolves raced through the ruins. Three launched themselves onto a mounted soldier, dragging the heavy armor down, crushing one of the wolves under the horse’s body while the others latched onto the rider’s face. Goobers mobbed humans. A unit of human reinforcements arrived and split off, pressing the goobers in and around crumbled piles of stone. Yelling, clashing, stamping, groans of the injured underfoot; it all merged into a furious din of indistinct sound. There was no sense to anything anymore. It was chaos.  

Camren charged her horse ahead of everyone and disappeared into the swarm, Skylar close behind. The magic hurdy gurdy was loud, but it didn’t have infinite reach. Skylar dropped off her horse and started to play, dancing around the edge of a bloody fight before her. She needed to inspire as many of their goober friends as possible.  

Trebor spoke the last words of the fire spell and his weapon lit up. He crept around piles of rubble. It was hard to see in this helmet. Also: it smelled. Focusing on these things helped him keep his wits in an otherwise witless situation.  

Gawain was more than happy to stay far back from the swinging swords and pikes. He aimed high for a soldier positioned on top of a pair of towers. The arrow struck and the man stumbled back. Then he raised his glaive and slammed it down on the stones.  

Lightning razed every goober and wolf within a large circle of the soldier. Charred corpses crumpled. Camren smelled burning flesh as the goober mere steps away from her smouldered under the searing heat. She urged her horse underneath the archway adjoining the towers the spellcaster was on. A blind impulse to strike down the spellcaster before whatever happened next pushed her forward: that, and the reassuring sound of the hurdy gurdy. It was the only recognizable noise in the death squall.  

Gawain knocked another arrow and aimed for the second human standing on the high ground. This shot was even more clean than the first. It should’ve been more than enough, but the woman didn’t even so much as flinch at the arrow protruding from her side. Her attention was fully on Gawain now. The air grew cold.  

Ice daggers shot across the field, killing several goobers instantly. Gawain fell to his knees and stared in horror at the spikes protruding from his body. Trebor was down too. A grizzled shard of ice twisted out of his chest. Red began to watercolor the slick ice.  

Against all logic both of them stood up again. Gawain fired over and over at the sorcerer. No arrows were enough to bring the enemy down.  

From the edge of the battlefield they heard it: a bone-chilling screech. The elder goober stood on a pile of stones and wailed. Humans fell to their knees. Wolves descended on their prone bodies instantly. Camren found herself in the center of that awful nail-on-stone noise; she clapped her hands over her ears and scrunched her eyes shut.  

The goobers were overpowering the enemy. Rallied by the sound of Skylar’s hurdy gurdy, they ferociously stabbed and slashed their way through the organized humans. There was no way the two spellcasters atop the ruined towers were going to survive this. Gawain, Trebor, and Skylar all saw the two silhouettes on the wall getting closer, glaives extended.  

Camren did not.  

She clambered up the rubble to the top of one tower in time to witness two glaives cracking together.  

Everything went white.  

When the noiseless nothing faded, a massive dip of blackened earth was all that remained of the towers and everything around it.  

Two heavily armored horsemen galloped past Gawain and Trebor. Lashed to one of the saddles was the goober shaman. Skylar saw it too, and began yelling to the others. Her head pounded and her voice sounded like it was far away, underwater, drowning in a pillow. All anyone could hear was a high pitched whine. Goobers and humans alike wandered the field, dazed.  

Skylar ripped Trebor off the ground, great helm and all, and threw him onto the back of her horse. Gawain tried to catch up with the horsemen holding the elder hostage and ended up in combat with yet more riders rallying to the action. All this with icicles still bleeding from his chest.  

The humans took their hostage and ran.  

Camren rolled out of the way, stunned, confused, and disoriented. Two soldiers had been dragging her away when she regained consciousness. She’d surprised them with a sudden return to life and got away only to be nearly stampeded over.  

Nobody was in any condition to fight. The party regrouped and scavenged for anything helpful, any healing goo, heck, even a drink would be nice, but there was little to find except busted armor, some rations, and weapons.  

Trebor dug his fingers into the chin strap securing a helmet on one of the fallen. Surely this would be the perfect fit. He didn’t get to finish what he was doing, though.  

“We need to rest,” Gawain said, picking ice out of his body and tying up the holes with torn fabric.  

“If we wait we’ll be too late,” Camren replied. “Trebor saw a floor plan. That’s where we need to be. We don’t have much choice: if we stay here, we’ll be caught up in the fighting again.”  

The sounds of combat around them hadn’t gotten any quieter. Whatever the suicidal blast that had just happened signalled, they didn’t know, and didn’t care to stick around and find out. They limped through the rubble in the direction the soldiers took the elder.  

On the steps of the keep from the vision, Trebor stopped and groaned. He pulled the icicle from his chest. Camren slumped on the steps. She couldn’t survive another hit, she knew. If the adrenaline stopped they’d all be dead. Skylar fussed with her instrument and wondered if she should play now. Everyone looked defeated.  

Camren pushed the doors open and prayed they wouldn’t creak or slam. She put herself between the next set of double doors and the party and hoped Trebor would find something useful in the side room. Gawain closed the entrance behind them.  

Four halberdiers burst through the interior doors and the fighting began all over again. Camren and Gawain slay one of the men while Trebor frantically dug through boxes and found only clothes and personal items. Two of the halberdiers escaped, running into the keep and yelling.  

The door behind Gawain banged. He slammed the iron bar over the holders. The four of them tore into the next room, closing and barring those doors too. The team scrambled away from the sound of pounding feet, shutting and blockading doors, rushing up a spiral stairwell, down a corridor, and right into the weapons of an armed group of five soldiers.  

Backed up into a bedroom Camren and Trebor fought, separated from Skylar and Gawain down the hall. Gawain’s arrows zipped into the cluster of attackers.  

Four more halberdiers came from the back stairwell and surrounded Gawain.  

The last of their heroism expended, things looked grim.  

Gawain realized the people surrounding him were not human at all. One of the big fighters shoved his face towards Gawain, grunted “dorkbois,” and turned.  

The dorkbois, large, ugly by human standards, bashed into the soldiers like a hot knife through butter. The fighting quickly ended with five dead humans.  

Camren tried to follow the dorkbois up the next flight of stairs and promptly found her face buried in a hand. The dorkbois pushed her back and she knew not to go with them.  

After the dorkbois came goobers. The goobers looked at the four ragged adventurers, shrugged, and went back downstairs.  

“Help me get this helmet off this guy,” Trebor said, tossing his great helm and the coif it came with onto the floor with a heavy thud. With Gawain’s help he got a new, lighter helmet. Could this be it? Could this be the perfect hat?  

Cheering came from upstairs. The dorkbois freed the elder goober; everyone rested for the night at the keep.  

The elder goober hit Trebor in the head and communicated the importance of this keep. Ancestral land, a meeting (or breeding?) ground for the goobers, and a key connector between the lands of several different races. The humans had held power over the area via the keep. The goobers could not stay and protect this area. They had no need for weird human caves. The elder offered for the party to stay here and prevent the humans from taking charge again.  

After being washed ashore, nearly murdered (several times) by the privateer, hearing the terrifying supernatural shrieks of some being living in an ancient temple, fighting in several skirmishes and a war, on top of Skylar’s continual shouts that the group should “make a base,” all four decided to go along with the elder goober’s offer.  

Beds. This place had actual beds.  

Of course the keep’s doors were destroyed, much like the magical cape that could’ve been saved if only everyone hadn’t been so busy furiously pounding the guy who wore it into a bloody pulp. The damage to the keep elsewhere was extensive but not irreparable. The basement had a cave in, upstairs was scratched and beaten, searched and destroyed. Where doors once might have been there were only frames.  

The keep also contained a library of foreign gibberish and a map, presumably of the area, though no one was sure.  

Over the next few days all four found out they knew little in the way of repairs. In their attempts to fix the front doors Gawain was crushed, knocked utterly unconscious. It was nothing like the magical heroism of before. Something was different. The book? Trebor concluded it was the storyteller’s book.  

They tried stabbing each other to see if the book had any effect. It did: everyone bled and questioned their sanity. Camren was furious she’d even listened to Trebor’s suggestion in the first place, and she hoarded the storyteller’s book jealousy for a day or two, refusing to let any of the others touch it.  

Eventually she gave in to Trebor’s prodding, since he was the only other one who could understand a whit of the human language here.  

Trebor discovered the purpose of the storyteller’s book. A feather quill was hidden in the binding, which, when written with, gave vitality to the group. However, it only did so long as they continued to record. If nothing fresh was written, if the words were only sentences long, the effect quickly faded.  

This is that book.

  
